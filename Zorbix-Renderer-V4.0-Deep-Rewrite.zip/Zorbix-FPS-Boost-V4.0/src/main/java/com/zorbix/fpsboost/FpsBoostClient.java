package com.zorbix.fpsboost;

import com.zorbix.fpsboost.config.ZorbixConfig;
import com.zorbix.fpsboost.gui.ZorbixOptionsScreen;
import com.zorbix.fpsboost.renderer.ZorbixRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.*;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class FpsBoostClient implements ClientModInitializer {
    public static final ZorbixConfig CONFIG = new ZorbixConfig();
    public static final ZorbixRenderer RENDERER = new ZorbixRenderer();
    public static KeyBinding OPTIONS_KEY;

    @Override public void onInitializeClient() {
        OPTIONS_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zorbix.options", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, "category.zorbix"));
        ClientTickEvents.END_CLIENT_TICK.register(FpsBoostClient::tick);
    }

    private static void tick(MinecraftClient client) {
        while (OPTIONS_KEY.wasPressed()) client.setScreen(new ZorbixOptionsScreen(client.currentScreen));
        if (client.options != null && CONFIG.consumeDirty()) applyVanilla(client);
        RENDERER.tick(client);
    }

    private static void applyVanilla(MinecraftClient client) {
        if (client.options.getParticles().getValue() != CONFIG.particles) client.options.getParticles().setValue(CONFIG.particles);
        if (client.options.getCloudRenderMode().getValue() != CONFIG.clouds) client.options.getCloudRenderMode().setValue(CONFIG.clouds);
        if (client.options.getGraphicsMode().getValue() != CONFIG.graphics) client.options.getGraphicsMode().setValue(CONFIG.graphics);
        if (client.options.getAo().getValue() != CONFIG.ambientOcclusion) client.options.getAo().setValue(CONFIG.ambientOcclusion);
        if (client.options.getEntityShadows().getValue() != CONFIG.entityShadows) client.options.getEntityShadows().setValue(CONFIG.entityShadows);
        if (client.options.getBobView().getValue() != CONFIG.viewBobbing) client.options.getBobView().setValue(CONFIG.viewBobbing);
        double fov = CONFIG.fovEffects ? 1.0 : 0.0;
        if (client.options.getFovEffectScale().getValue() != fov) client.options.getFovEffectScale().setValue(fov);
    }
}
