package com.zorbix.fpsboost.renderer.culling;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;

public final class ZorbixCulling {
    private ZorbixCulling() {}
    public static boolean entityVisible(Frustum f, Entity e, double cx, double cy, double cz, int maxDistance) {
        double dx=e.getX()-cx, dy=e.getY()-cy, dz=e.getZ()-cz;
        double d=maxDistance;
        if(dx*dx+dy*dy+dz*dz>d*d) return false;
        return f==null || f.isVisible(e.getBoundingBox().expand(0.15D));
    }
    public static boolean blockEntityVisible(Frustum f, BlockEntityRenderDispatcher d, BlockEntity be, double cx, double cy, double cz, int maxDistance) {
        BlockEntityRenderer r=d.get(be);
        if(r!=null && r.rendersOutsideBoundingBox(be)) return true;
        double x=be.getPos().getX()+0.5D,y=be.getPos().getY()+0.5D,z=be.getPos().getZ()+0.5D;
        double dx=x-cx,dy=y-cy,dz=z-cz,max=maxDistance;
        if(dx*dx+dy*dy+dz*dz>max*max) return false;
        return f==null || f.isVisible(new Box(x-.5,y-.5,z-.5,x+.5,y+.5,z+.5));
    }
}
