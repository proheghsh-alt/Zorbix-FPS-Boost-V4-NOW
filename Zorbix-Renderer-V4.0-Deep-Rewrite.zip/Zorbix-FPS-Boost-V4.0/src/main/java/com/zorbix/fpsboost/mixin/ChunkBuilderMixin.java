package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkBuilder.class)
public abstract class ChunkBuilderMixin {
    @Shadow private int processablePrioritizedTaskCount;
    @Shadow private volatile int queuedTaskCount;

    @Inject(method="scheduleRunTasks", at=@At("HEAD"))
    private void zorbix$tuneScheduler(CallbackInfo ci) {
        if(!FpsBoostClient.CONFIG.rendererEnabled || !FpsBoostClient.CONFIG.chunkScheduler) return;
        int q=queuedTaskCount;
        int budget=FpsBoostClient.CONFIG.prioritizedTaskBudget;
        // Keep urgent rebuilds flowing, but prevent a giant priority queue from starving normal work.
        processablePrioritizedTaskCount = q > 32 ? Math.max(2, budget / 2) : budget;
    }
}
