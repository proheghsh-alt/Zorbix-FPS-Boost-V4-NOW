package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.gui.ZorbixOptionsScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.option.VideoOptionsScreen;
import net.minecraft.client.gui.widget.OptionListWidget;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(VideoOptionsScreen.class)
public abstract class VideoOptionsMixin {
    @Shadow @Final private OptionListWidget list;
    @Inject(method="init", at=@At("TAIL"))
    private void zorbix$button(CallbackInfo ci) {
        SimpleOption<Boolean> option=SimpleOption.ofBoolean("Zorbix Renderer 4.0", SimpleOption.constantTooltip(Text.literal("Open the Zorbix renderer control center.")), (name,value)->Text.literal("Open Zorbix"), false, value->{ MinecraftClient c=MinecraftClient.getInstance(); c.setScreen(new ZorbixOptionsScreen((VideoOptionsScreen)(Object)this)); });
        list.addSingleOptionEntry(option);
    }
}
