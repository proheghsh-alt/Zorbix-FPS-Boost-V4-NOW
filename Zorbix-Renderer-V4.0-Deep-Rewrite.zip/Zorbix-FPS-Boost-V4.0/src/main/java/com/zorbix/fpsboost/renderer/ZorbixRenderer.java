package com.zorbix.fpsboost.renderer;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.Vec3d;

/** Frame profiler and renderer state. No per-frame heap allocation in the hot path. */
public final class ZorbixRenderer {
    private long frame;
    private long renderNanos;
    private long terrainNanos;
    private long frameStart;
    private int terrainDrawCalls;
    private int terrainChunks;
    private int entityVisible, entityCulled, blockVisible, blockCulled;
    private int chunksToBatch, chunksToUpload;
    private double frameMs, terrainMs;

    public void beginFrame() {
        frame++;
        frameStart = System.nanoTime();
        terrainNanos = 0L;
        terrainDrawCalls = 0;
        terrainChunks = 0;
        entityVisible = entityCulled = blockVisible = blockCulled = 0;
    }

    public void finishFrame(WorldRenderer wr) {
        renderNanos = System.nanoTime() - frameStart;
        frameMs = renderNanos / 1_000_000.0;
        terrainMs = terrainNanos / 1_000_000.0;
        if (wr != null && wr.getChunkBuilder() != null) {
            chunksToBatch = wr.getChunkBuilder().getToBatchCount();
            chunksToUpload = wr.getChunkBuilder().getChunksToUpload();
        }
    }

    public void tick(MinecraftClient client) {
        // Deliberately never touches render/simulation distance.
    }

    public void terrainBegin() { }
    public void terrainEnd(long start) { terrainNanos += System.nanoTime() - start; }
    public void terrainChunk() { terrainChunks++; }
    public void terrainDraw() { terrainDrawCalls++; }
    public void entityVisible() { entityVisible++; }
    public void entityCulled() { entityCulled++; }
    public void blockVisible() { blockVisible++; }
    public void blockCulled() { blockCulled++; }

    public long frame() { return frame; }
    public double frameMs() { return frameMs; }
    public double terrainMs() { return terrainMs; }
    public int terrainDrawCalls() { return terrainDrawCalls; }
    public int terrainChunks() { return terrainChunks; }
    public int entityVisible() { return entityVisible; }
    public int entityCulled() { return entityCulled; }
    public int blockVisible() { return blockVisible; }
    public int blockCulled() { return blockCulled; }
    public int chunksToBatch() { return chunksToBatch; }
    public int chunksToUpload() { return chunksToUpload; }
}
