package com.zorbix.fpsboost.renderer.terrain;

import com.zorbix.fpsboost.FpsBoostClient;
import com.zorbix.fpsboost.mixin.WorldRendererAccess;
import com.zorbix.fpsboost.mixin.WorldRendererChunkInfoAccess;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import net.minecraft.client.gl.VertexBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

/**
 * Zorbix terrain front-end. It consumes the already-built GPU meshes, but owns
 * the layer traversal, empty-layer rejection and draw scheduling. This is the
 * safe first stage of a renderer replacement; mesh generation remains vanilla
 * until a compatible backend is available.
 */
public final class ZorbixTerrainRenderer {
    private ZorbixTerrainRenderer() {}

    public static void renderLayer(WorldRenderer renderer, RenderLayer layer, MatrixStack matrices,
                                    double cameraX, double cameraY, double cameraZ, Matrix4f positionMatrix) {
        if (!FpsBoostClient.CONFIG.rendererEnabled || !FpsBoostClient.CONFIG.customTerrainRenderer) {
            ((WorldRendererAccess) renderer).zorbix$invokeVanillaRenderLayer(layer, matrices, cameraX, cameraY, cameraZ, positionMatrix);
            return;
        }
        long start=System.nanoTime();
        layer.startDrawing();
        ObjectArrayList<?> infos=((WorldRendererAccess)renderer).zorbix$getChunkInfos();
        for(int i=0,n=infos.size();i<n;i++) {
            Object info=infos.get(i);
            ChunkBuilder.BuiltChunk chunk=((WorldRendererChunkInfoAccess)info).zorbix$getChunk();
            if(chunk==null || chunk.getData()==null || chunk.getData().isEmpty(layer)) continue;
            if(FpsBoostClient.CONFIG.terrainRenderRadius>0) {
                double dx=chunk.getOrigin().getX()+8.0-cameraX, dy=chunk.getOrigin().getY()+8.0-cameraY, dz=chunk.getOrigin().getZ()+8.0-cameraZ;
                double r=FpsBoostClient.CONFIG.terrainRenderRadius;
                if(dx*dx+dy*dy+dz*dz>r*r) continue;
            }
            VertexBuffer buffer=chunk.getBuffer(layer);
            if(buffer==null || buffer.isClosed()) continue;
            matrices.push();
            matrices.translate(chunk.getOrigin().getX()-cameraX, chunk.getOrigin().getY()-cameraY, chunk.getOrigin().getZ()-cameraZ);
            RenderSystem.applyModelViewMatrix();
            buffer.bind();
            buffer.draw();
            RenderSystem.applyModelViewMatrix();
            matrices.pop();
            FpsBoostClient.RENDERER.terrainChunk();
            FpsBoostClient.RENDERER.terrainDraw();
        }
        VertexBuffer.unbind();
        layer.endDrawing();
        FpsBoostClient.RENDERER.terrainEnd(start);
    }
}
