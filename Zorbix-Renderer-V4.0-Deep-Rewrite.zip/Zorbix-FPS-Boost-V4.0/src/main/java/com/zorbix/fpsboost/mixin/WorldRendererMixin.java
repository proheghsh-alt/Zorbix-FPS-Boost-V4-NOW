package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.FpsBoostClient;
import com.zorbix.fpsboost.renderer.terrain.ZorbixTerrainRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(method="setupTerrain", at=@At("HEAD"))
    private void zorbix$begin(Camera camera, Frustum frustum, boolean forced, boolean spectator, CallbackInfo ci) {
        if(FpsBoostClient.CONFIG.rendererEnabled) FpsBoostClient.RENDERER.beginFrame();
    }

    @Inject(method="render", at=@At("TAIL"))
    private void zorbix$finish(MatrixStack matrices, float tickDelta, long limitTime, boolean blockOutline, Camera camera,
                                net.minecraft.client.render.GameRenderer gameRenderer,
                                net.minecraft.client.render.LightmapTextureManager lightmap,
                                Matrix4f projection, CallbackInfo ci) {
        FpsBoostClient.RENDERER.finishFrame((WorldRenderer)(Object)this);
    }

    @Redirect(method="render", at=@At(value="INVOKE", target="Lnet/minecraft/client/render/WorldRenderer;renderLayer(Lnet/minecraft/client/render/RenderLayer;Lnet/minecraft/client/util/math/MatrixStack;DDDLorg/joml/Matrix4f;)V"))
    private void zorbix$terrain(WorldRenderer self, RenderLayer layer, MatrixStack matrices, double x, double y, double z, Matrix4f position) {
        ZorbixTerrainRenderer.renderLayer(self, layer, matrices, x, y, z, position);
    }
}
