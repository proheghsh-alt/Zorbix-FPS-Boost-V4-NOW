package com.zorbix.fpsboost.config;

import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** Runtime configuration. Hot-path options are read as primitive fields. */
public final class ZorbixConfig {
    public boolean rendererEnabled = true;
    public boolean customTerrainRenderer = true;
    public boolean frustumCulling = true;
    public boolean entityCulling = true;
    public boolean blockEntityCulling = true;
    public boolean chunkScheduler = true;
    public boolean profilerHud = true;
    public boolean fogOptimization = true;
    public boolean particleCulling = true;

    public int entityCullingDistance = 64;
    public int blockEntityCullingDistance = 48;
    /** Extra terrain radius in blocks. 0 means keep vanilla view distance. */
    public int terrainRenderRadius = 0;
    /** Number of prioritized rebuild tasks allowed before normal work is considered. */
    public int prioritizedTaskBudget = 8;

    public ParticlesMode particles = ParticlesMode.MINIMAL;
    public CloudRenderMode clouds = CloudRenderMode.OFF;
    public GraphicsMode graphics = GraphicsMode.FAST;
    public boolean ambientOcclusion = false;
    public boolean entityShadows = false;
    public boolean viewBobbing = true;
    public boolean fovEffects = true;

    private boolean dirty = true;
    public void markDirty() { dirty = true; }
    public boolean consumeDirty() { if (!dirty) return false; dirty = false; return true; }

    public void applyProfile(String profile) {
        switch (profile) {
            case "QUALITY" -> { customTerrainRenderer = true; frustumCulling = true; entityCulling = true; blockEntityCulling = true; terrainRenderRadius = 0; prioritizedTaskBudget = 4; }
            case "POTATO" -> { customTerrainRenderer = true; frustumCulling = true; entityCulling = true; blockEntityCulling = true; terrainRenderRadius = 128; prioritizedTaskBudget = 12; particles = ParticlesMode.MINIMAL; clouds = CloudRenderMode.OFF; graphics = GraphicsMode.FAST; ambientOcclusion = false; entityShadows = false; }
            default -> { customTerrainRenderer = true; frustumCulling = true; entityCulling = true; blockEntityCulling = true; terrainRenderRadius = 0; prioritizedTaskBudget = 8; particles = ParticlesMode.MINIMAL; clouds = CloudRenderMode.OFF; graphics = GraphicsMode.FAST; ambientOcclusion = false; entityShadows = false; }
        }
        dirty = true;
    }
}
