package com.zorbix.fpsboost.mixin;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets="net.minecraft.client.render.WorldRenderer$ChunkInfo")
public interface WorldRendererChunkInfoAccess {
    @Accessor("chunk") ChunkBuilder.BuiltChunk zorbix$getChunk();
}
