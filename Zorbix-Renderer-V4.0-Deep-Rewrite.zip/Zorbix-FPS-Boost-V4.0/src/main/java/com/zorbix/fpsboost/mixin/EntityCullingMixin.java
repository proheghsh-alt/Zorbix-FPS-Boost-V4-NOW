package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.FpsBoostClient;
import com.zorbix.fpsboost.renderer.culling.ZorbixCulling;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(WorldRenderer.class)
public abstract class EntityCullingMixin {
    @Shadow private Frustum frustum;
    @Inject(method="renderEntity", at=@At("HEAD"), cancellable=true)
    private void zorbix$cull(Entity entity, double cameraX, double cameraY, double cameraZ, float tickDelta,
                             MatrixStack matrices, VertexConsumerProvider consumers, CallbackInfo ci) {
        if(!FpsBoostClient.CONFIG.rendererEnabled || !FpsBoostClient.CONFIG.entityCulling) return;
        if(!ZorbixCulling.entityVisible(frustum, entity, cameraX,cameraY,cameraZ,FpsBoostClient.CONFIG.entityCullingDistance)) {
            FpsBoostClient.RENDERER.entityCulled(); ci.cancel();
        } else FpsBoostClient.RENDERER.entityVisible();
    }
}
