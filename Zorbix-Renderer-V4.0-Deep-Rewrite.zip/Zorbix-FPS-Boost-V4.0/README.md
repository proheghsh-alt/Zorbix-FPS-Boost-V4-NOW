# Zorbix Renderer 4.0 — Minecraft 1.20.1

This release is the first real renderer-layer rewrite rather than a settings-only FPS mod.

## What is actually implemented
- Zorbix-owned terrain layer traversal: the vanilla `WorldRenderer.renderLayer` call is redirected to a Zorbix renderer front-end. It consumes Minecraft's already-built chunk GPU meshes and owns the visible-chunk traversal, empty-layer rejection and draw scheduling.
- Entity culling before entity renderer invocation.
- Block-entity distance culling with renderer safety for renderers that draw outside their normal box.
- ChunkBuilder scheduler tuning using the actual 1.20.1 prioritized task queue.
- Per-frame renderer profiler counters: terrain chunks/draws, entity/block-entity culling and chunk build/upload backlog.
- No render-distance or simulation-distance manipulation.

## Important engineering boundary
A Sodium-class renderer does more than a Fabric mixin: it replaces chunk mesh generation, storage/regions and GPU upload strategy. This 4.0 release deliberately starts replacing the render front-end while keeping vanilla mesh generation compatible with mods. It does not claim to have reproduced Sodium's private architecture or performance.

The next measured step is to use the built-in profiler counters on the target Android/OpenGL ES device. If terrain draw time dominates, the next backend can replace the mesh storage/upload layer without guessing. If game tick/server time dominates, renderer rewrites cannot fix that bottleneck.

## Build
GitHub Actions uses Java 17 and Gradle 8.4.
