package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.gui.hud.DebugHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.List;

@Mixin(DebugHud.class)
public abstract class DebugHudMixin {
    @Inject(method="getLeftText", at=@At("RETURN"))
    private void zorbix$hud(CallbackInfoReturnable<List<String>> cir) {
        if(!FpsBoostClient.CONFIG.profilerHud) return;
        List<String> out=cir.getReturnValue();
        out.add("Zorbix Renderer 4.0: ACTIVE");
        out.add(String.format("Z terrain: %.2f ms | draws %d | chunks %d", FpsBoostClient.RENDERER.terrainMs(), FpsBoostClient.RENDERER.terrainDrawCalls(), FpsBoostClient.RENDERER.terrainChunks()));
        out.add(String.format("Z culling: E %d/%d | BE %d/%d", FpsBoostClient.RENDERER.entityCulledCount(), FpsBoostClient.RENDERER.entityVisibleCount(), FpsBoostClient.RENDERER.blockCulledCount(), FpsBoostClient.RENDERER.blockVisibleCount()));
        out.add(String.format("Z chunk queue: build %d | upload %d", FpsBoostClient.RENDERER.chunksToBatch(), FpsBoostClient.RENDERER.chunksToUpload()));
    }
}
