package com.zorbix.fpsboost.mixin;

import com.zorbix.fpsboost.FpsBoostClient;
import com.zorbix.fpsboost.renderer.culling.ZorbixCulling;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockEntityRenderDispatcher.class)
public abstract class BlockEntityRenderDispatcherMixin {
    @Shadow private net.minecraft.client.render.Camera camera;
    @Shadow private net.minecraft.client.world.ClientWorld world;
    private Frustum zorbix$frustum;

    @Inject(method="render", at=@At("HEAD"), cancellable=true)
    private <E extends BlockEntity> void zorbix$cull(E be, float tickDelta, MatrixStack matrices, VertexConsumerProvider consumers, CallbackInfo ci) {
        if(!FpsBoostClient.CONFIG.rendererEnabled || !FpsBoostClient.CONFIG.blockEntityCulling || camera==null) return;
        // WorldRenderer owns the canonical frustum; block entities are additionally distance culled here.
        double x=camera.getPos().x,y=camera.getPos().y,z=camera.getPos().z;
        if(!ZorbixCulling.blockEntityVisible(null, (BlockEntityRenderDispatcher)(Object)this, be, x,y,z,FpsBoostClient.CONFIG.blockEntityCullingDistance)) {
            FpsBoostClient.RENDERER.countBlockCulled(); ci.cancel();
        } else FpsBoostClient.RENDERER.countBlockVisible();
    }
}
