package com.zorbix.fpsboost.gui;

import com.zorbix.fpsboost.FpsBoostClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class ZorbixOptionsScreen extends Screen {
    private final Screen parent;
    public ZorbixOptionsScreen(Screen parent){ super(Text.literal("Zorbix 4.0 Renderer")); this.parent=parent; }
    @Override protected void init(){
        int w=240,x=(width-w)/2,y=65;
        addDrawableChild(ButtonWidget.builder(Text.literal("Terrain Renderer: "+on(FpsBoostClient.CONFIG.customTerrainRenderer)),b->{FpsBoostClient.CONFIG.customTerrainRenderer=!FpsBoostClient.CONFIG.customTerrainRenderer;clearAndInit();}).dimensions(x,y,w,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Entity Culling: "+on(FpsBoostClient.CONFIG.entityCulling)),b->{FpsBoostClient.CONFIG.entityCulling=!FpsBoostClient.CONFIG.entityCulling;clearAndInit();}).dimensions(x,y+25,w,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Block Entity Culling: "+on(FpsBoostClient.CONFIG.blockEntityCulling)),b->{FpsBoostClient.CONFIG.blockEntityCulling=!FpsBoostClient.CONFIG.blockEntityCulling;clearAndInit();}).dimensions(x,y+50,w,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Chunk Scheduler: "+on(FpsBoostClient.CONFIG.chunkScheduler)),b->{FpsBoostClient.CONFIG.chunkScheduler=!FpsBoostClient.CONFIG.chunkScheduler;clearAndInit();}).dimensions(x,y+75,w,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Potato Profile"),b->{FpsBoostClient.CONFIG.applyProfile("POTATO");clearAndInit();}).dimensions(x,y+110,w,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Balanced Profile"),b->{FpsBoostClient.CONFIG.applyProfile("BALANCED");clearAndInit();}).dimensions(x,y+135,w,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"),b->close()).dimensions(x,y+175,w,20).build());
    }
    private static String on(boolean v){return v?"ON":"OFF";}
    @Override public void close(){ if(client!=null) client.setScreen(parent); }
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){ renderBackground(ctx); ctx.drawTextWithShadow(textRenderer,title,width/2-textRenderer.getWidth(title)/2,35,0xFFFFFF); super.render(ctx,mouseX,mouseY,delta); }
}
